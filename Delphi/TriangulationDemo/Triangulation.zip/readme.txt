This demo is intended to showcase Clipper's triangulation.

The widely used OpenGL graphics library is a perfect example of why triangulation might be useful. In OpenGL, the only way to draw vectored polygons (including text) is to triangulate them first. This demo uses Clipper to triangulate complex polygons that are then displayed using OpenGL (requires vers 3.0 or higher).